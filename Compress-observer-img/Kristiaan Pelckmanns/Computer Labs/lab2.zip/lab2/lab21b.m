% Computer laboratory number 2, "Time Series Modelling and
% Prediction" in the System Identification Course. 
%
% The lab consists of the following steps. For a given time series
% (one constructed and one real data series), do data
% prediction. In order to get a stationary time series, the student
% first has to remove  
% any polynomial trend from the data, which includes finding the
% order of the polynomial trend, the polynomial coefficients. The
% effect of the order will be discussed in some detail
% (tail-waving). As a next step, any periodical component in the
% data has to be removed. Different methods can be considered: AR,
% FFT, etc. Make a new FFT to see the effect of the removal of
% periodicities. Finally, determine the best predictor for the data and
% check how it performs. 
% 
% This file generates the data from the fictituous data model
%
% y(t)=1/A(q) x(t) + p(t) + \sum_k=1^K A_k sin(w_kt+phi_k)
%
% that is an AR model with sinusoids and a polynomial trend
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Generate the raw data
echo off
K=3;       % Number of sinusoids
N=1000;    % Number of data points
M=300;	   %       - " -          used in estimation
tN=1:N;
maxlag=10;
t=tN(1:M+maxlag);
time=tN(1:M+maxlag);
zpad=2^15;


e_w=randn(N,1);
x=randn(N,1);

om=[1.24 1.51 1.6]'; 
fi=[3 3 6]'; 
a=ones(K,1);

A=[1 0.64 0.7];
%A=[1 -2.76 3.809 -2.654 0.924];
B=[1];

x=filter(B,A,e_w); 

p=[5e-2 1e-3];
%p=[3e-5 0.0142 0.0177];

y=x+(a'*sin(om*tN+fi*ones(size(tN))))' + polyval(p,tN)';
y=y(1:M+maxlag);

save data

zoom off
clf;figure(1);zoom xon
clear; load data;

z=y;

% Plot the raw data

subplot(211)
plot(t(1:M)',z(1:M));
title('Raw data')
ylabel('z(t)')
xlabel('t')

subplot(212)
P=periodogram(z(1:M));
P=P(M/2+1:M);
f=linspace(0,1,M/2)';
semilogy(f,P)
title('Periodogram raw data')
xlabel('Normalized frequency')
ylabel('Periodogram')
