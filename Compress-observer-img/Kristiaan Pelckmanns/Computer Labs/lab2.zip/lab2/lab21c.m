% Computer laboratory number 2, "Time Series Modelling and
% Prediction" in the System Identification Course. 
%
% The lab consists of the following steps. For a given time series
% (one constructed and one real data series), do data
% prediction. In order to get a stationary time series, the student
% first has to remove  
% any polynomial trend from the data, which includes finding the
% order of the polynomial trend, the polynomial coefficients. The
% effect of the order will be discussed in some detail
% (tail-waving). As a next step, any periodical component in the
% data has to be removed. Different methods can be considered: AR,
% FFT, etc. Make a new FFT to see the effect of the removal of
% periodicities. Finally, determine the best predictor for the data and
% check how it performs. 
% 

zoom off
clf;figure(1);zoom xon
clear; load data;

z=y;

% Plot the raw data

subplot(211)
plot(time(1:M)',z(1:M));
title('Raw data')
ylabel('z(t)')
xlabel('t')

subplot(212)
P=periodogram(z(1:M),zpad);
P=P(zpad/2+1:zpad);
f=linspace(0,1,zpad/2)';
plot(f,P)
title('Periodogram raw data')
xlabel('Normalized frequency')
ylabel('Periodogram')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Estimate polynomial trend
%
disp(' ')
n=input('Give order of polynomial trend: ');

phat=polyfit(t(1:M)',z(1:M),n);

subplot(211)
hold on
plot(time(1:M)',polyval(phat,t(1:M)),'-r');
hold off
legend('Raw data','Polynomial trend',0)

disp('Hit any key to remove polynomial trend...')
pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Remove polynomial trend
%

z=z-polyval(phat,t');

subplot(211)
plot(time(1:M)',z(1:M));
title('Data with polynomial trend removed')
ylabel('z(t)')
xlabel('t')

subplot(212)
P=periodogram(z(1:M),zpad);

P=P(zpad/2+1:zpad);
f=linspace(0,1,zpad/2)';

plot(f,P)
%plot(P)
title('Periodogram polynomial trend removed')
xlabel('Normalized frequency')
ylabel('Periodogram')

disp('Estimation of sinusoidal frequencies...')
disp(' ')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Estimate peaks
%
n=input('Give the number of sinusoids: ');

fhat=f(findpeaks(-P,n)');

disp(['fhat=',num2str(sort(fhat)')]);

subplot(212)
ax=axis;
ax=ax(3:4)';
line([1;1]*fhat',ax*ones(1,n))
title('Periodogram, estimated peak frequencies')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Estimate data
%

Ph=[cos(pi*fhat*t) ; sin(pi*fhat*t)];
th=inv(Ph*Ph')*Ph*z;

zsin=Ph'*th;

subplot(211)
hold on
plot(time(1:M)',zsin(1:M),'-r')
hold off
legend('Data','Estimated sinusoidal data')

disp('Hit any key to remove sinusoidal data...')
pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Remove sinusoidal data
%

z=z-zsin;

subplot(211)
plot(time(1:M)',z(1:M));
title('Data with sinusoid(s) removed')
ylabel('z(t)')
xlabel('t')

subplot(212)
P=periodogram(z(1:M),zpad);
P=P(zpad/2+1:zpad);
f=linspace(0,1,zpad/2)';
plot(f,P)
title('Periodogram with sinusoid(s) removed')
xlabel('Normalized frequency')
ylabel('Periodogram')

disp('Hit any key to select the order of the model...')
pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Choose a model order
%

V=[];
Ahat=[];
si2=0;

nmax=50;
Sys=zeros(nmax,nmax+1);
 V(1)=z(1:M)'*z(1:M)/M;
aic(1)=M*log(V(1));
for n=1:nmax,

  %r=xcov(z(1:M),z(1:M),n,'biased');
  %R=toeplitz(r(n+1:2*n+1));

  %ah=-inv(R(2:n+1,2:n+1))*R(2:n+1,1);
  tth=ar(z(1:M),n);
  Ahat=th2poly(tth);
  %Ahat=[1 ah'];
  Sys(n,1:n+1)=Ahat; 
  %si2(n)= R(1,1:n+1)*Ahat';
 
  e=filter(Ahat,1,z(1:M));
 

  V(n+1)=e'*e/M;
  aic(n+1)=M*log(V(n+1))+2*n;
end

subplot(212)
plot(0:19,aic(1:20))
%plot(V(1:20))
title('AIC loss function V_N (\theta)')
xlabel('Number of parameters')
ylabel('Loss function')

% The short way...
%VV = arxstruc(z(1:250),z(250:300),[1:10]');
%nn = selstruc(VV);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Estimate AR system of order n
%
disp(' ');
norder=input('Give the order of the AR process: ');

Ahat=Sys(norder,1:norder+1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Compare AR spectrum 
%

clf

ind=exp(i*linspace(-pi,pi,M));
Phat=1/M*e'*e./(polyval(Ahat,ind).*polyval(Ahat,conj(ind)))';
Phat=Phat(round(M/2)+1:M);

f=linspace(0,1,zpad/2)';
fh=linspace(0,1,length(Phat))';
plot(f,P,fh,Phat)
title('True and estimated periodograms')
xlabel('Normalized frequency')
ylabel('Periodogram')
legend('Periodogram data','Estimated periodogram')
grid

disp('Hit any key to predict data ...')
pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Optimal predictor
%
tlag=t(M:M+maxlag);

zpred=[z(M-norder:M) ; zeros(size(tlag'))];

for k = norder+2 : maxlag+norder+1,
  zpred(k)=-Ahat(2:norder+1)*zpred(k-1:-1:k-norder);
end;

zpred=zpred(norder+1:maxlag+norder+1);

% Predicted AR data

subplot(211)
plot(time(M-maxlag:M+maxlag)',z(M-maxlag:M+maxlag),'-b',time(M:M+maxlag)',zpred,'-r');

title(['Crossvalidation AR data, Prediction starts at Jan 1987'])
ax=axis;
line([time(M) time(M)],[ax(3) ax(4)])
legend('Measured data','Predicted data',0)
ylabel('y(t)')
xlabel('t')

% total data

Ph=[cos(pi*fhat*tlag) ; sin(pi*fhat*tlag)];
zsin=Ph'*th;
zpoly=polyval(phat,tlag');
zptot=zpred+zsin+zpoly;

subplot(212)
plot(time(M-maxlag:M+maxlag)',y(M-maxlag:M+maxlag),'-b',time(M:M+maxlag)',zptot,'-r');

title(['Crossvalidation total data, Prediction starts at Jan 1987'])
ax=axis;
line([time(M) time(M)],[ax(3) ax(4)])
legend('Measured data','Predicted data',0)
ylabel('z(t)')
xlabel('t')









