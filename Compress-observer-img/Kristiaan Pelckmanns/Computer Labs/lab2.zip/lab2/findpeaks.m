%
% function ind = findpeaks(f, n, thi);
%
% Function to find the n deepest minima to f
%
function ind = findpeaks(f, n, thi);

ind = zeros(1,n); 
indmin = find(diff(sign(diff(f))) > 0) + 1; 
[fmin, k] = sort(f(indmin)); 
nmin = min(n, length(k));
ind(1:nmin) = indmin(k(1:nmin))';
if (nargin == 3), ind(1:nmin) = sort(thi(ind(1:nmin))); end;

