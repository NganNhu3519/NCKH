% Computer laboratory number 2, "Time Series Modelling and
% Prediction" in the System Identification Course. 
%

% 

clear
K=3;       % Number of sinusoids
N=1000;    % Number of data points
tN=1:N;
M=300;
maxlag=10;
t=tN(1:M+maxlag);
time=tN(1:M+maxlag);
zpad=2^15;

% init noise
e_w=randn(N,1);
x=randn(N,1);

om=[1.24 1.51 1.6]'; 
fi=[3 3 6]'; 
a=ones(K,1);

% AR
A=[1 -2.76 3.809 -2.654 0.924];
B=[1];
y=filter(B,A,e_w); 

% add sinusoids
om=[1.24 1.51 1.6]'; 
fi=[3 3 6]'; 
a=ones(K,1);
p=[3e-5 0.0142 0.0177];
y=x+(a'*sin(om*tN+fi*ones(size(tN))))';
y=y(1:M+maxlag);


% Plot the raw data

subplot(211)
plot(time(1:M)',y(1:M));
title('Raw data')
ylabel('y_t')
xlabel('t')

subplot(212)
P=periodogram(y(1:M),zpad);
P=P(zpad/2+1:zpad);
f=linspace(0,1,zpad/2)';
plot(f,P)
title('Periodogram raw data')
xlabel('Normalized frequency')
ylabel('Periodogram')



%
% Estimate peaks
%
n=input('Give the number of sinusoids: ');

fhat=f(findpeaks(-P,n)');

disp(['fhat=',num2str(sort(fhat)')]);

subplot(212)
ax=axis;
ax=ax(3:4)';
line([1;1]*fhat',ax*ones(1,n))
title('Periodogram, estimated peak frequencies')