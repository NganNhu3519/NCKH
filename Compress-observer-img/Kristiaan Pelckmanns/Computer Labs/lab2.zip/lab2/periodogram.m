%
% FUNCTION spectrum = periodogram( data, zeropadd, window )
%  
% The function calculates the periodogram of the given datasequence,
% zeropadding it to the length 'zeropadd' and windowing it with the
% the given 'window' sequence. By default the data is not zeropadded 
% and the window is rectangular.
%
%  
function spectrum = periodogram( data, zeropadd, window )

  N = length(data);
  if( nargin < 2 )
    zeropadd = N;
  end
  if( nargin < 3 )
    window = ones(N,1);
  end

  spectrum = abs( fftshift( fft(data.*window,zeropadd) ) ).^2 / N;
