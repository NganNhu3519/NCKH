% Computer laboratory number 2, "Time Series Modelling and
% Prediction" in the System Identification Course. 
%
% The lab consists of the following steps. For a given time series
% (one constructed and one real data series), do data
% prediction. In order to get a stationary time series, the student
% first has to remove  
% any polynomial trend from the data, which includes finding the
% order of the polynomial trend, the polynomial coefficients. The
% effect of the order will be discussed in some detail
% (tail-waving). As a next step, any periodical component in the
% data has to be removed. Different methods can be considered: AR,
% FFT, etc. Make a new FFT to see the effect of the removal of
% periodicities. Finally, determine the best predictor for the data and
% check how it performs. 
% 
% This file prepares real temperature data for processing
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Prepare the real data

load temperature;

X=stensele;
clear stensele;

year=flipud(X(:,1))';
X=flipud(X(:,2:13));
[N,m]=size(X);

% all data
Y=reshape(X',m*N,1);


% 1 month: 1=jan, 2=feb etc
% M=128;
% maxlag=N-M;
% y=X(:,month);
% y=y(1:M+maxlag);
% t=year(1:M+maxlag);

% all data

years=127+1/12;
M=round(12*years);
maxlag=24;
y=reshape(X',m*N,1);
y=y(1:M+maxlag);
%y(M+1)=y(M+1)+2;
time=linspace(year(1),year(1)+years+maxlag/12,M+maxlag+1);
time=time(2:M+maxlag+1);
t=1:M+maxlag;
zpad=2^15;


% Yearly average 
%M=128;
%maxlag=N-M;
%y=mean(X')';
%y=y(1:M+maxlag);
%t=year(1:M+maxlag);


save data;

zoom off
clf;figure(1);zoom xon
clear; load data;

z=y;

% Plot the raw data

subplot(211)
plot(time(1:M)',z(1:M));

title('Raw data')
ylabel('z(t)')
xlabel('t')

subplot(212)
P=periodogram(z(1:M),zpad);
P=P(zpad/2+1:zpad);
f=linspace(0,1,zpad/2)';
plot(f,P)
title('Periodogram raw data')
xlabel('Normalized frequency')
ylabel('Periodogram')




