%** ri_2: effect of the forgetting factor.
%*****************************************
clear;
N=200;
nn=10;
u=sign(randn(N,nn));e=randn(N,nn);
B1=[0 1.5];A=[1 -.8];

%idplot(z1);

nn2=[1 1 1];
th0=[0 0]; P0=1*eye(2);
c_vec=[1.5*ones(N/2,1); .5*ones(N/2,1)]; d_vec=-.8*ones(N,1);
lam=input('Give lambda [l1 l2 l3] (RETURN = default): ');
if(isempty(lam)), lam=[1 .95 .85];
elseif (length(lam)~=3)
  error(' Wrong input');
end
  
for n=1:nn
[y1,xx]=filter(B1,A,u(1:N/2,n));
B2=[0 .5];
y=[y1;filter(B2,A,u(N/2+1:N,n),xx)]+filter(1,A,e(:,n));
z1=[y u(:,n)];

[Thm3(:,:,n),yhat,P]=rarx(z1,[1 1 1],'ff',lam(1),th0,P0);
[Thm4(:,:,n),yhat,P]=rarx(z1,nn2,'ff',lam(2),th0,P0);
[Thm5(:,:,n),yhat,P]=rarx(z1,nn2,'ff',lam(3),th0,P0);
end
thm3=mean(Thm3,3);
std3=std(Thm3,0,3);
thm4=mean(Thm4,3);
std4=std(Thm4,0,3);
thm5=mean(Thm5,3);
std5=std(Thm5,0,3);

subplot(3,1,1);
plot([1:N],thm3,'r',1:N,[thm3+std3 thm3-std3],'r:',[1:N],c_vec,'b',[1:N],d_vec,'b');
text(210,1.2,'b')
text(210,-1.3,'a')
axis([0 N -2 2]); grid; title(['lambda=',num2str(lam(1))]);   

%** lambda=0.97.
%***************


subplot(3,1,2);
plot([1:N],thm4,'r',1:N,[thm4+std4 thm4-std4],'r:',[1:N],c_vec,'b',[1:N],d_vec,'b');
text(210,1.2,'b')
text(210,-1.3,'a')
axis([0 N -2 2]); grid; title(['lambda=',num2str(lam(2))]); 

%** lambda=0.90.
%***************

subplot(3,1,3);
plot([1:N],thm5,'r',1:N,[thm5+std5 thm5-std5],'r:',[1:N],c_vec,'b',[1:N],d_vec,'b');
text(210,1.2,'b')
text(210,-1.3,'a')
axis([0 N -2 2]); grid; title(['lambda=',num2str(lam(3))]); 



