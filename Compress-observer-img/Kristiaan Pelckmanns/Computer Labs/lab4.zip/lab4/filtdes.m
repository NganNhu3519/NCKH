echo on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Interactive tool for designing butterworth filters
% of bandpass type. The passband is given by
% W1< W < W2, where W1 and W2 are given by clicking 
% twice with the left mouse button at desired
% frequencies in the plot. The order of the filter is 
% decided by the user as well.
%
% The function requires the existens of w and msys, given
% by the function gendata3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo off

close all
f1=figure
loglog(w,msys);grid
title('Frequency functions');
xlabel('Angular frequency'); ylabel('Amplitude');
[xx,yy]=ginput(2);
x=xx/pi;
n=input('Give the desired order of the filter (RETURN gives order 5) : ');
if (isempty(n)), n=5;end

[nn,dd]=butter(n,x')
 th=poly2th(dd,nn);
 subplot(2,1,2)
 zpplot(th2zp(th));
 title('Pole-zero plot for filter')
 [mag,pha,w2]=dbode(nn,dd,1,w);
 subplot(2,1,1)
 loglog(w,msys,w,mag,':');
mmm=max(max(msys),max(mag))+10;
 axis([0.1 10 0.1 mmm])
 legend('Sys','Filter')
