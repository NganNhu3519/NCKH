%** lab4b.m: effect of the initial values.
%**************************************
clear; clf
N=250; e=randn(N,1);

%** Generate input
%************************
u=sign(randn(N,1));
%** Simulate system.
%*******************
a=-0.9; b=0.5; A=[1 a]; B=[0 b];
y=filter(B,A,u)+filter(1,A,e);

%** Using RLS with different initial values of rho.
%**************************************************
nn=[1 1 1];
z=[y u]; th0=[0 0];
a=-0.9*ones(N,1); b=0.5*ones(N,1);

%** rho=0.01.
%************
P01=0.01*eye(2);
[thm1,yhat,P]=rarx(z,nn,'ff',1,th0,P01);
subplot(2,2,1);
plot([1:N],thm1,[1:N],a,'k',[1:N],b,'k');
axis([0 N -1 1]); title('rho=0.01');

%** rho=0.1.
%***********
P02=0.1*eye(2);
[thm2,yhat,P]=rarx(z,nn,'ff',1,th0,P02);
subplot(2,2,2);
plot([1:N],thm2,[1:N],a,'k',[1:N],b,'k');
axis([0 N -1 1]); title('rho=0.1');

%** rho=1.
%*********
P03=1*eye(2);
[thm3,yhat,P]=rarx(z,nn,'ff',1,th0,P03);
subplot(2,2,3);
plot([1:N],thm3,[1:N],a,'k',[1:N],b,'k');
axis([0 N -1 1]); title('rho=1');

%** rho=10.
%**********
P04=10*eye(2);
[thm4,yhat,P]=rarx(z,nn,'ff',1,th0,P04);
subplot(2,2,4);
plot([1:N],thm4,[1:N],a,'k',[1:N],b,'k');
axis([0 N -1 1]); title('rho=10');

