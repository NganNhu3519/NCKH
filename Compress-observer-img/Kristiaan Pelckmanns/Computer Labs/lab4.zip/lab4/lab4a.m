%** General comparison.
%**********************
clear; 
N=input('Number of samples N (RETURN gives N=250): ');
if (isempty(N)), N=250;end
u=randn(N,1); e=randn(N,1);clf;
a=-0.7; b=0.8; A=[1 a]; B=[0 b];
%av=a*ones(N,1);bv=b*ones(N,1);
y=filter(B,A,u)+e; z=[y u];

%** RLS.
%*******
nn=[1 1 1];
thm=rarx(z,nn,'ff',1);
a_vec=-0.7*ones(N,1); b_vec=0.8*ones(N,1);
subplot(2,2,1);
plot([1:N],thm(:,1),'y',[1:N],thm(:,2),'m',[1:N],a_vec,'r',[1:N],b_vec,'r');
axis([0 N -2 2]); grid; title('RLS');

%** RIV.
%*******
P=10000*eye(2);
th=[0; 0];
thmat=th;
for i=3:N
	phi=[-y(i-1); u(i-1,1)];
	Z=[u(i-1,1); u(i-2,1)];
	P=P-P*Z*phi'*P/(1+phi'*P*Z);
	ee=y(i)-phi'*th;
	th=th+P*Z*ee;
	thmat=[thmat th];
end 
subplot(2,2,2);
plot([1:N-1],thmat(1,:),'y',[1:N-1],thmat(2,:),'m',[1:N],a_vec,'r',[1:N],b_vec,'r')
axis([0 N -2 2]); grid; title('RIV');

%** RPLR.
%********
nn1=[1 1 1 0 0 1];
thm1=rplr(z,nn1,'ff',1);
subplot(2,2,3);
plot([1:N],thm1(:,1),'y',[1:N],thm1(:,2),'m',[1:N],thm1(:,3),'c',[1:N],a_vec,'r',[1:N],b_vec,'r');
axis([0 N -2 2]); grid; title('RPLR');

%** RPEM.
%********
thm2=rpem(z,nn1,'ff',1);
subplot(2,2,4);
plot([1:N],thm2(:,1),'y',[1:N],thm2(:,2),'m',[1:N],thm2(:,3),'c',[1:N],a_vec,'r',[1:N],b_vec,'r');
axis([0 N -2 2]); grid; title('RPEM');

  
