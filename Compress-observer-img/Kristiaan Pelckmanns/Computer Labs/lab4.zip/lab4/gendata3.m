%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% gendata3.m
%Generate data DC motor.
%Set parameters
 
K=4;
T=0.5;
ramp=1;
lambda=1;
a=0.5;
h=0.1;
tper=8;
ttot=80;
 
%Generate model
A=[0 1;0 -1/T];B=[0;K/T];C=[1 0];
[F,G]=c2d(A,B,h);
%[bsys,asys]=ss2tf(F,G,C,0,1)   
%Generate signals
time=0:h:ttot;
np=ttot/h;
e=randn(np+1,1)*sqrt(lambda);
rr=kron(ones(ttot/tper/2,1),[1;-1]);
u=kron(rr,ones(tper/h,1));u=[1;u(:)];
 
[y0,x]=dlsim(F,G,C,0,u);
y=y0+e;
plot(time,[y,u]),title('output and input')   
