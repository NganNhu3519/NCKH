num=[0 0 1 -1.3 .8];
den=conv([1 -1.5 .9],[1 0 .9]);
[msys,psys,w]=dbode(num,den,1);
u=sign(randn(100,1));
y=filter(num,den,u);
z=[y u];
nn=1;dd=1;
