%** ri_2: effect of the forgetting factor.
%*****************************************
clear;
N=200;
u=sign(randn(N,1));e=randn(N,1);
B1=[0 1.5];A=[1 -.8];
[y1,xx]=filter(B1,A,u(1:N/2));
B2=[0 .5];
y=[y1;filter(B2,A,u(N/2+1:N),xx)]+filter(1,A,e);
z1=[y u];
%idplot(z1);

nn2=[1 1 1];
th0=[0 0]; P0=1*eye(2);
c_vec=[1.5*ones(N/2,1); .5*ones(N/2,1)]; d_vec=-.8*ones(N,1);
lam=input('Give lambda [l1 l2 l3] (RETURN = default): ');
if(isempty(lam)), lam=[1 .95 .85];
elseif (length(lam)~=3)
  error(' Wrong input');
end
  


%** lambda=1.
%************
[thm3,yhat,P]=rarx(z1,[1 1 1],'ff',lam(1),th0,P0);
subplot(3,1,1);
plot([1:N],thm3,[1:N],c_vec,'r',[1:N],d_vec,'r');
text(210,1.2,'b')
text(210,-1.3,'a')
axis([0 N -2 2]); grid; title(['lambda=',num2str(lam(1))]);   

%** lambda=0.97.
%***************
[thm4,yhat,P]=rarx(z1,nn2,'ff',lam(2),th0,P0);
subplot(3,1,2);
plot([1:N],thm4,[1:N],c_vec,'r',[1:N],d_vec,'r');
text(210,1.2,'b')
text(210,-1.3,'a')
axis([0 N -2 2]); grid; title(['lambda=',num2str(lam(2))]); 

%** lambda=0.90.
%***************
[thm5,yhat,P]=rarx(z1,nn2,'ff',lam(3),th0,P0);
subplot(3,1,3);
plot([1:N],thm5,[1:N],c_vec,'r',[1:N],d_vec,'r');
text(210,1.2,'b')
text(210,-1.3,'a')
axis([0 N -2 2]); grid; title(['lambda=',num2str(lam(3))]); 