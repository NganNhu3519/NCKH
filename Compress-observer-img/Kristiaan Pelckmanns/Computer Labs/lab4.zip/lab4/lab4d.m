% Model approximation -- frequency domain effects
clf

echo on
% In order to run the file, the following variables must exist:
%
% The input (u) and output (y) and the magnitude
% (msys) and phase (psys) of
% the system transfer function for the frequencies (w).
% All given by the file gendata2.
%
% Filternumerator (nn) and filerdenominator (dd), which can
% be provided by the function filtdes.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo off
%Estimation based on filtered data
filtnum=nn;%input('Give filtnumerator with [] ')
filtden=dd;%input('Give filtdenominator with [] ')

yf=filter(filtnum,filtden,y);
uf=filter(filtnum,filtden,u);
that1=armax([yf uf],[2 2 2 1]);

[m1,p1]=bode(that1,w);m1=squeeze(m1);p1=squeeze(p1);
[mf,pf]=dbode(filtnum,filtden,1,w);

format short
subplot(121)
loglog(w,m1,w,msys,'--',w,mf,':')
title('Frequency functions');
xlabel('Angular frequency'); ylabel('Amplitude');

mmax=max(max(m1),max(max(msys),max(mf)))+10;
axis([0.1 10 0.1 mmax])
legend('Est','Sys','Filt',0)

subplot(122);
semilogx(w,p1,w,psys,'--'); hold off;
title('Frequency functions');
ylabel('Phase'),xlabel('Angular frequency')
