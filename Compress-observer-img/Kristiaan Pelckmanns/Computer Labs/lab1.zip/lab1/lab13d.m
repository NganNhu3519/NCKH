%file lab13d.m
%Computer Laboratory 1
%System Identification

% Correlation analysis

clear
a=-0.8;b=1;A=[1 a];B=[0 b];sigma=1;t=10;n=100;m=20;
e=randn(n,100)*sigma;
u=sign(randn(n,100));
aa=-.8;
u2=filter(1,[1 aa],u)/sqrt(2.77); %u2 with variance 1
y=filter(B,A,u2)+filter(1,A,e);

% build Wiener-Hopf equations
for k=0:m-1
 ryu(k+1,1:100)=diag((y(k+1:n,:))'*u2(1:n-k,:))'/n;
end
h(1,1)=0;
for k=1:m-1
 h(k+1,1)=b*(-a)^(k-1);
end
a2=-aa;
for k=0:m-1
v(k+1)=a2^k;
end	
Rm=toeplitz(v);
hest=Rm\ryu; % solve


h_mean=mean(hest')';
h_var=std(hest')';

%hest=hest(:);h=h(:);
subplot(211)
%stem([0:m-1],[hest(:,1),h])
plot([0:m-1],[hest(:,1),h])
title('Correlation analysis low frequency input: weighting functions')
xlabel('time lag')
legend('Estimated','True')

subplot(212)
plot([0:m-1],[h_mean(:,1),h],[0:19],[h_mean+h_var,h_mean-h_var],'r--')
%stem([0:m-1],[h_mean(:,1),h h_mean+h_var,h_mean-h_var])
title('Averaged over 100 simulations')
xlabel('time lag')
legend('Mean of estimates','True','Standard deviation')
