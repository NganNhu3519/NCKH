%file lab13e.m
%Computer Laboratory 
%System Identification

% Spectral analysis

clear
a=-0.8;b=1;A=[1 a];B=[0 b];sigma=1;t=10;n=100;m=20;
e=randn(n,100)*sigma;
u=sign(randn(n,100));
aa=-.8;
u2=filter(1,[1 aa],u)/sqrt(2.77); %u2 with variance 1
y=filter(B,A,u2)+filter(1,A,e);

% spectral analysis
M=input('Give M ')
w=logspace(-2,pi);
for k=1:100,
  z=[y(:,k),u2(:,k)];
  gest=spa(z,M,w);
  [tmp1 tmp2]=bode(gest);
  mest(1:50,k)=squeeze(tmp1);pest(1:50,k)=squeeze(tmp2);
end;
m_mean=mean(mest')'; p_mean=mean(pest')';
m_var=std(mest')'; p_var=std(pest')';
[mtrue,ptrue]=dbode(B,A,1,w);

%  plot result
subplot(211)
loglog(w,[mest(:,1),mtrue,m_mean]), hold on
loglog(w,[m_mean+m_var,m_mean-m_var],'r--'), hold off
xlabel('Angular frequency'),ylabel('Amplitude')
txt=['Spectral analysis, M = ', num2str(M)];
title(txt)
legend('Estimate (one example)','True','Mean and std of 100 simulations',3)
subplot(212)
semilogx(w,[pest(:,1),ptrue,p_mean]), hold on
semilogx(w,[p_mean+p_var,p_mean-p_var],'r--'), hold off
xlabel('Angular frequency'),ylabel('Phase')
title(txt);
legend('Estimate (one example)','True','Mean and std of 100 simulations',3)

