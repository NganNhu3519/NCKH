%file lab13b.m
%Computer Laboratory 1
%System Identification

% Correlation analysis

clear
a=-0.8;b=1;A=[1 a];B=[0 b];sigma=1;t=10;n=100;m=20;
e=randn(n,100)*sigma;
u=sign(randn(n,100));
aa=-.8;
u2=filter(1,[1 aa],u)/sqrt(2.77); %u2 with variance 1
y=filter(B,A,u2)+filter(1,A,e);


for k=1:m, hest(k,1:100)=diag((y(k+1:n,:))'*u(1:n-k,:))'/n;end
for k=1:m, h(k,1)=b*(-a)^(k-1);end
h_mean=mean(hest')';
h_var=std(hest')';

%hest=hest(:);h=h(:);
subplot(211)
plot([1:20],[hest(:,1),h])
title('Correlation analysis: weighting functions')
xlabel('time lag')
legend('Estimated','True')

subplot(212)
plot([1:20],[h_mean(:,1),h],[1:20],[h_mean+h_var,h_mean-h_var],'r--')
title('Averaged over 100 simulations')
xlabel('time lag')
legend('Mean of estimates','True','Standard deviation')