%file lab2a.m
%Computer Laboratory 1
%System Identification

% Transient analysis
clear
a=-0.8;b=1;A=[1 a];B=[0 b];sigma=1;t=10;n=100;

e=randn(n,100)*sigma;
u=ones(n,1);
y1=filter(B,A,u);y=y1*ones(1,100)+filter(1,A,e);
ym=mean(y')';
yvar=std(y')';

subplot(211)
plot([1:100],[y(:,1),y1])
axis([0 100 -2 8])
title('Step responses, one realization')
% (y solid line, true dashed line)')
legend('output y','noise free output',4)

subplot(212)
plot([1:100],[ym,y1],[1:100],[ym+yvar,ym-yvar],'r--')
axis([0 100 -2 8])
title('Step responses, averaged over 100 simulations')
% (y solid line, true dashed line)')
legend('mean output y','noise free output','standard deviation',4)
