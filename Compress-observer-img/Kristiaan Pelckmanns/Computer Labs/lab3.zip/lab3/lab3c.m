% file lab3c.m 
% Use of LSM (ARX model)
%Computer Laboratory 3 in System Identification 
%TS 920315, rev TS 950405, rev KB 000211, rev EKL 010110

clf
format compact

nlag=10;resl=[]; plsm=[]; zlsm=[];
np=length(y);
nmax=6;
for n=1:nmax,   
  that1=iv4(ze,[n n 1]);   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change the above command to use prediction error method %
% or instrumental variable method according to            %
%                                                         %
% that1=armax([y u],[n n n 1]);                           %
% that1=iv4([y u],[n n 1]);                               %
% (or use that1=iv([y u],[n n 1],1,[zeros(1,n),1]);)      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 eval(['TH' num2str(n) '=that1;']); % to save that1 for n=1:nmax
 %present(that1);
 [comp1(n),fit1(n)]=compare(ze,that1);
 [comp2(n),fit2(n)]=compare(zv,that1);            
 V(n)=that1.EstimationInfo.LossFcn;
 FPE(n)=that1.EstimationInfo.FPE;
 AIC(n)=log(V(n))*np+2*2*n; 
 % Modify the AIC for ARMAX because we have n more free variables!
 % i.e. AIC(n)=log(that1(1,1))*np+3*2*n;   
 format short    
end;

echo on
%b) testing based on the covariance functions
echo off
for n=1:nmax
  eval(['resid(TH' num2str(n) ',ze);']);
 subplot(211)
 txt=['autocorrelation of residual e, n=',num2str(n)];
 title(txt)
 subplot(212)
 txt=['crosscorrelation between e and u, n=',num2str(n)];
 title(txt)
 pause
end;

echo on
%c)  measured output and model output
%    for the estimation data set.
echo off
mm=min([100 np]);
for n=1:nmax
  subplot(320+n);
  plot(1:mm,[comp1{n}.y(1:mm),y(1:mm)]);
  title(['n = ',num2str(n),' Fit :',num2str(fit1(n))]);  
  legend('y_m','y',0)
end;
pause
echo on
%   measured output and model output
%   for the validation data set.
echo off
for n=1:nmax
  subplot(320+n);
  plot(1:mm,[comp2{n}.y(1:mm) ,yv(1:mm)]);
  title(['n = ',num2str(n),' Fit :',num2str(fit2(n))]);  
  legend('y_m','y',0)
end;
pause
echo on

%d) loss function, AIC and FPE
echo off
clf
subplot(311)
plot(1:nmax,V), title('loss function'), xlabel('n')
subplot(312)
plot(1:nmax,AIC), title('AIC'), xlabel('n')
subplot(313)
plot(1:nmax,FPE), title('FPE'), xlabel('n')
pause

clf
echo on
%e) pole-zero plot with confidens regions
%   corresponding to 3 standard deviations. 
echo off
subplot(221)
for n=1:nmax
  eval(['zpplot(TH' num2str(n) ',3);']);
  title(['Poles and zeros ARX, n = ',num2str(n)])
   pause
end


