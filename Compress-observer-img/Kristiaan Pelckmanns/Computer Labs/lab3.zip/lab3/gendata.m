np=250
a0=[1 -1.5 0.7], b0=[0 1 .5], c0=[1 -1.0 0.2],
s2=1, l2=1
u=sign(randn(2*np,1))*sqrt(s2); e=randn(2*np,1);

th=idpoly(a0,b0,c0,1,1,l2);
y=idsim([u e],th);
uv=u(np+1:end);ev=e(np+1:end);yv=y(np+1:end);
u=u(1:np);e=e(1:np);y=y(1:np);
ze=iddata(y,u);zv=iddata(yv,uv);